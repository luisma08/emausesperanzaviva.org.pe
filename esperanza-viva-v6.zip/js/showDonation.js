'use strict';

const donacion1 = document.querySelector('.donacion-1');
const donacion2 = document.querySelector('.donacion-2');
const donacion3 = document.querySelector('.donacion-3');
const donacion4 = document.querySelector('.donacion-4');
const donacion5 = document.querySelector('.donacion-5');
const donacion6 = document.querySelector('.donacion-6');
const donacion7 = document.querySelector('.donacion-7');
const donacion8 = document.querySelector('.donacion-8');
const donacionContent1 = document.querySelector('.donacion-content-1');
const donacionContent2 = document.querySelector('.donacion-content-2');
const donacionContent3 = document.querySelector('.donacion-content-3');
const donacionContent4 = document.querySelector('.donacion-content-4');
const donacionContent5 = document.querySelector('.donacion-content-5');
const donacionContent6 = document.querySelector('.donacion-content-6');
const donacionContent7 = document.querySelector('.donacion-content-7');
const donacionContent8 = document.querySelector('.donacion-content-8');

donacion1.addEventListener("click", () => {

    donacionContent1.classList.remove("d-none");
    donacionContent2.classList.add("d-none");
    donacionContent3.classList.add("d-none");
    donacionContent4.classList.add("d-none");
    donacionContent5.classList.add("d-none");
    donacionContent6.classList.add("d-none");
    donacionContent7.classList.add("d-none");
    donacionContent8.classList.add("d-none");

});

donacion2.addEventListener("click", () => {

    donacionContent2.classList.remove("d-none");
    donacionContent1.classList.add("d-none");
    donacionContent3.classList.add("d-none");
    donacionContent4.classList.add("d-none");
    donacionContent5.classList.add("d-none");
    donacionContent6.classList.add("d-none");
    donacionContent7.classList.add("d-none");
    donacionContent8.classList.add("d-none");

});

donacion3.addEventListener("click", () => {

    donacionContent3.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');

});

donacion4.addEventListener("click", () => {

    donacionContent4.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');

});

donacion5.addEventListener("click", () => {

    donacionContent5.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');

});

donacion6.addEventListener("click", () => {

    donacionContent6.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent7.classList.add('d-none');
    donacionContent8.classList.add('d-none');

});

donacion7.addEventListener("click", () => {

    donacionContent7.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent8.classList.add('d-none');

});

donacion8.addEventListener("click", () => {

    donacionContent8.classList.remove("d-none");
    donacionContent1.classList.add('d-none');
    donacionContent2.classList.add('d-none');
    donacionContent3.classList.add('d-none');
    donacionContent4.classList.add('d-none');
    donacionContent5.classList.add('d-none');
    donacionContent6.classList.add('d-none');
    donacionContent7.classList.add('d-none');

});